# slides-to-app: install

Turns a Google Slides deck into a published web app (scroll page or click-through deck), and optionally a Tableau data app published with the Tableau Cloud connector, with an optional mock CSV data source.

## Install

1. Unzip, and move the `slides-to-app` folder into `~/.claude/skills/` so you have `~/.claude/skills/slides-to-app/SKILL.md`.
2. Restart Claude Code. Check that `slides-to-app` appears in the skills list.

## You need

- **Google Slides connector** in Claude Code (it reads the deck). The deck must be shared with you.
- **Node.js 24+** and npm.
- **git** and the **GitHub CLI** logged in (`gh auth login`), for publishing to GitHub Pages. GitHub Desktop works too: the skill can commit, and you push.
- **Tableau Cloud connector** (Tableau MCP), only for the data app step, with permission to publish to a project or your Personal Space.
- macOS is assumed for image resizing (`sips`), `zip` and `unzip`.

## Use

Paste a Google Slides link and ask, e.g. "turn this deck into a web app". The skill asks which GitHub account to use, where to save the project, the format and the theme, and shows a mockup before building. It asks again before anything is published to GitHub or Tableau.

If you keep your own GitHub account rules in `~/.claude/CLAUDE.md`, the skill follows them.
